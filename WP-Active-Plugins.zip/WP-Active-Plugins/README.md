# WP-Active-Plugins
A Must Have Debugging Tool for Wordpress developers to grab a list of all activated plugins before they are going to turn them off for a debugging sessions. 
